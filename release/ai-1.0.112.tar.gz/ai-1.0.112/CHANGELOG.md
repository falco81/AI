# ai — what changed

Every change is a new version: the number is in `ai.py` (`ai --version`), on
the pages (Settings → About), in the name of the folder and of the archive.

## 1.0.112

- **Ollama: Free the GPU** (Settings → Ollama → What Ollama has, or `ai --ollama-free`): every model Ollama holds is
  unloaded at once (`keep_alive: 0` for each one `/api/ps` lists) - the GPU's memory and the RAM of its machine are
  free, for a game or anything else, with nothing restarted. Ollama loads a model again by itself at the next
  question.
- **Free the GPU when the last chat ends** (a setting, off at first): once no chat with Ollama runs any more - the
  last one ended here, or Claude Code in it quit - the same is done by itself.

## 1.0.111

- **Tables**: a tag (YES, 128K, ADMINISTRATOR…) sat 2-5 px lower than the words and the buttons of its row - it
  went by the text's baseline. Every word, tag and button of a row is on one line now (measured on every table of
  the settings: Ollama's models, Claude Code's accounts, the accounts, backups, certificates…).

## 1.0.110

**Chats with Ollama: "exceeded the output token maximum" after a few words, again and again** - three faults, each
fixed:

- The copy of the model with the context set in it (1.0.106) was never asked: the chat also gave Claude Code
  `--model` with the model's own name, and that went over `ANTHROPIC_MODEL`. Ollama answered with the model as it
  is - 4k or 16k of context.
- Claude Code takes a model it does not know to hold a million tokens ("context assumed to be 1m tokens"), so it
  never compacted the conversation; it outgrew the model's context, and Ollama stopped every answer at once -
  which Claude Code reports as "exceeded the output token maximum". A chat with Ollama now tells Claude Code the
  window it really has (`CLAUDE_CODE_AUTO_COMPACT_WINDOW`), and it compacts in time.
- The longest answer is never more than half the model's context.

The list of chats says what a chat with Ollama runs with: *Ollama MODEL · 128k* (or *context not set*). A chat
started before: *Start it again*.

## 1.0.109

- **Tables**: a row with a button or a tag in it is lined up through its middle - the words sat at the top of
  the row, the buttons and tags lower down (Ollama's models and its measure, Claude Code's accounts, the accounts,
  who is signed in, and every other table with buttons in its rows).

## 1.0.108

- **Ollama's measure**, made right: the model is unloaded before each size, so each is really loaded with its own
  context (every size measured the same before - the model was answered from as it was loaded); the column
  *Given* says how much context Ollama really gave each time (from `/api/ps`), a size it cut down counts as not
  reached; the model is found in `/api/ps` also when it is listed with or without `:latest`, asked again while it
  is still loading.

## 1.0.107

**Ollama: measured, then recommended.** *Measure* by each model (Settings → Ollama → What Ollama has → *For Claude
Code*) loads it on the machine of Ollama with 16k, 32k, 64k and 128k of context in turn, asks it for a few words,
and shows how much of it is in the GPU, how much spills into the machine's RAM (Ollama shares it by itself:
slower), and how many tokens a second it writes. It recommends the most context that is whole in the GPU, or -
when that is under the 64k Claude Code needs - the least that reaches 64k with the RAM, with its speed. *Use this*
keeps that context for the model: its chats run with it ([docs/ollama.md](docs/ollama.md)).

## 1.0.106

**Chats with Ollama keep the context they need, wherever Ollama runs.** The context set in Ollama's app or service
is not what a model always gets - Ollama gives less when the model and its context do not fit the GPU (256k set,
16k given to a 12B model in Q8 on 16 GB) - and with too little the model forgot the folder it works in and the
conversation, asked "which script, which folder?", and ran on to the output limit. Now a chat runs ai's copy of
its model with the context set in it (`num_ctx`, from *Context length to set*, 64k at first), made in Ollama the
first time (a few kB, the weights are not copied: `qwen3-coder:30b-ai64k`); never more than the model holds; the
copies are not offered as models of their own. *Each model with that context* switches it off. A chat started
before: *Start it again*. [docs/ollama.md](docs/ollama.md) says what fits on how much GPU.

## 1.0.105

**Chats with Ollama: "Claude's response exceeded the 128000 output token maximum"** on anything harder. Ollama gives a
model only 4096 tokens of context by default (under 24 GB of VRAM); Claude Code's system prompt and tools do not
fit, the model loses the thread and writes on until the limit. Ollama recommends at least 64000
([docs/ollama.md](docs/ollama.md)):

- **What Ollama has** shows the context each loaded model has now (*Context now*, from Ollama's `/api/ps`), in
  orange under 64000, and whether a model runs partly on the CPU; a note says when there is too little.
- **Set it on this server's Ollama**: `OLLAMA_CONTEXT_LENGTH` in a systemd drop-in of ai's own
  (`ollama.service.d/ai-context.conf`, 65536 at first - *Context length to set*), Ollama started again; *Take it
  away again* removes it. For Ollama elsewhere, what to set there is said.
- **Longest answer** (`CLAUDE_CODE_MAX_OUTPUT_TOKENS`, 32000 at first) for chats with Ollama: an answer that runs on
  stops there, not after 128000 tokens.

## 1.0.104

- **The list of terminals**: its headings (PINNED, THE OTHERS) were cut in half once the list was longer than the
  screen - the list squeezed them to make room. They keep their height now.
- **Taking many off the list at once** (the right button on a terminal, or on the list): besides every ended one,
  - every ended one that is not pinned,
  - every ended shell, every ended command, every ended Claude Code
  (each offered only where it differs from "every ended one", with how many). The confirm says how many pinned
  ones are among them.
- A command whose program has ended but whose last screen is still held (claude doctor, an update) counts as
  ended for these, and for *Take every ended one off the list*: it is ended first, then taken off. Before, it was
  left behind.

## 1.0.103

Bugs found by a review of the terminals, the files, the backups and the database, and the system's panes - each
one fixed:

- **Security - an account's files are touched as that account now, never as root.** The daemon is root; an
  account whose terminals run as its own Linux account could put a link in its home and have root follow it:
  - moving a chat to another folder copied its transcript as root - a transcript that was a link to /etc/shadow,
    into a folder that was a link to /etc, both then given to the account;
  - the .gitignore of the folder of files given to Claude, a link to /etc/profile.d/…, was written by root;
  - Settings of Claude Code (agents, commands, settings.json…) made folders and wrote through a link as root;
  - an upload's file was given its owner by name: swapped for a link to /etc/shadow during the upload, root gave
    /etc/shadow away;
  - the Files tab worked as root on the paths an account controls (a link swapped in between the check and the
    work).
  Every file of a person who is not an administrator is now read, written, made, renamed and taken away as the
  Linux account they run as (the kernel checks it, root's way past permissions is gone for that moment); uploads
  and every file ai writes get their owner and mode on the open file, never by name.
- **Files: a link is renamed or taken away itself**: taking away a link to a folder emptied the folder it pointed
  to; renaming it renamed the file it pointed to, in that file's folder. The files of a chat keep renaming and
  taking away inside the chat's folder too.
- **Security - the second step**: its wrong codes were counted with the password's, so the right password given
  again cleared them - eight guesses at a time, for ever. They are counted apart now.
- **Security - changing your own password** ends your other sign-ins (one opened with a stolen cookie went on for
  up to a week).
- **The firewall's "goes back by itself"** did not put back who may reach the pages: on a fresh installation it
  "went back" to the new setting, the firewall was rebuilt from the setting being taken back, and the setting it
  put back had the wrong shape (the pages open to everybody at the next save). A second change while the first
  is on trial now goes back to how it was before both.
- **Locked out** (Accounts) broke whenever anybody was locked out; passkey and second-step locks can be cleared
  one by one.
- A change of the network interrupted by a restart of ai blocked every later change for good.
- **Export and import**: one setting this machine cannot take (a Linux account it has not) stopped the import half
  done - it is left out and said now; an import that replaces dropped `claude_env` (the API key of the
  terminals) when the file had no secrets; the ECDSA twin of the certificate went out still sealed with this
  machine's key and was lost on the other.
- Passwords in the settings lost their spaces at the ends (a backup password "secret " locked with "secret").
- **The database**: "empty the other database" could empty the live one reached under another name - the live
  one is now told by a mark made in it at that moment; the password in use was sent to a newly typed server
  when the box was left dotted; MariaDB's table sizes and free space were always empty; the weekly check of a
  copy said NOT GOOD after a restore that brought another key.
- Starting a chat again after its account's Linux account was changed left it unreachable (attach, keys, end).
- A FIFO named like a transcript held a thread of the daemon for ever.
- **The terminal's last line** was cut in half: xterm counted the padding and the border of its box as room for
  rows. It is whole now, in every size, full screen and with the files or the writing box open.
- **Claude Code's accounts** (Settings → Claude Code) say whether a newer Claude Code is out (npm's *latest*,
  asked every 6 hours, through the proxy where installing Claude Code goes through it); *Update it* is then the
  blue button, and the table is read afresh each time the pane is opened.

## 1.0.102

- **An open list closed by itself**: on the Terminals tab with no chat open, the start page was drawn again every few
  seconds and gave the keys back to its own box - taking them from an open dialog, so a list open in it (the model of a
  new chat…) closed under the mouse. It takes them only when it is first shown now, and never from a dialog or another
  box. Every tab and every pane of the settings was checked the same way (a list open, the page scrolled half down,
  waited): nothing else takes the keys or moves the page.
- **A long menu closed while it was scrolled** (the models of a new chat): scrolling the menu itself no longer closes
  it; scrolling the page still does.
- **A new chat starts with Claude**: *Every option…* chose an Ollama model by itself when no model was remembered,
  and the last chat's Ollama model was offered again. Claude (as Claude Code chooses) is the default now; Ollama is
  chosen for one chat at a time.

## 1.0.101

**Chats with Ollama** - a chat can talk to a model of Ollama instead of Claude ([docs/ollama.md](docs/ollama.md)):

- **Settings → Ollama**: switched on or off, for every account or administrators only, Ollama on this server (its
  port) or elsewhere on the network (its address, a key when a proxy in front asks for one), the model offered
  first and the one for the small tasks. *Try it* asks Ollama with what is written, before it is saved.
- **What Ollama has**, found by itself: its version (0.14 and newer has the Anthropic API Claude Code needs), its
  models with their size, parameters, context, and whether they use tools (Claude Code works by tools).
- **A new chat**: the model chip lists Claude (subscription) and Ollama's models; *Every option…* too. The chat
  runs the same Claude Code, pointed at Ollama (`ANTHROPIC_BASE_URL`, the model for every part), past the proxy.
  It keeps the choice when started again; *Change…* moves it between Ollama's models and Claude's, the
  conversation with it. A model Ollama does not have is refused before anything changes.
- On the server: `ai --ollama` (what Ollama has), `ai --new DIR --ollama [MODEL]`.

## 1.0.100

Bugs found by a review of 1.0.58 - 1.0.90 (acme push, passkeys, the load, the notices), each one fixed:

- **Security - passkeys**:
  - an account taken away left its passkeys behind: a new account given the same name later could be signed into with
    them, no password. They go with the account now.
  - taking a passkey away (what the pages offer for a lost device) did not end the sign-ins it had opened - the device
    stayed signed in for up to a week. They end with it now (from the pages and from `ai --passkey-forget`).
  - registering a passkey could take over, or wipe, another account's passkey by naming its id. Refused now.
  - a stale passkey pressed a few times locked the whole address out of password sign-in (everybody behind the same NAT).
    Its failures are counted apart now.
- **acme push**: the twin (alt) certificate was put in unchecked - it now has to hold the same names and the other kind
  of key (one RSA, one ECDSA), as an upload's.
- A ZIP holding one PFX was refused with "is the password right?" - the ZIP itself was read as the PFX.
- `ai --set KEY=VALUE --get KEY` printed the old value and saved nothing; now it saves, then prints the new value.
- Two pages asking for the load at once could start two watchers (doubled readings), and a page asking in the moment the
  watching ended was left without readings.
- A notice said done on the command line stayed on the pages for a minute, and Done on it said "no such notice".
- The header's disk rates read the real `/sys/block` where the details read the configured sysfs.

## 1.0.99

Bugs found by a review of 1.0.91 - 1.0.98, each one fixed:

- **Security**: `?api=upgrade-state` (asked without signing in) gave who started an upgrade and why it failed to any
  request with a cookie that merely looked like a session. Those two now go only to a session the daemon confirms; the
  upgrade's id is always said as a hash.
- An upgrade that could not be started (the database busy, the helper missing…) after it was marked running left
  status.json and the pages' file "running" for 30 minutes - the band on every page, /healthz in maintenance, and every
  other upgrade refused meanwhile. Now it is marked failed at once, with why.
- install.sh: on a machine with SELinux on and no `semodule`, `httpd_can_network_connect` and `restorecon` were left out
  since 1.0.91 - nginx could not reach the daemon. They are done whenever SELinux is on; only the module needs semodule.
- SELinux: a step asked from the page while the half-hourly look ran could run beside it, and the step stayed "pending"
  for an hour. One at a time now (a lock), and what was done is re-read before it is written.
- Certificates: *Chain* stayed "incomplete" after the missing root was added to the system's trust - the file in place was
  checked again only when the certificate file changed; the system's roots count now too.
- The notice "trusted by browsers only" could say "The intermediate None is not sent" when the chain could not be checked.
- A chain that cannot be completed reloaded nginx after every start of the daemon - tried once per certificate now, kept
  across restarts.
- *Checked from here* connected to 127.0.0.1 even when nginx listens on an address of its own only.
- The upgrade's steps counted one too many with `--no-claude`.

## 1.0.98

- **Settings → SELinux looks as fake-igd's card**: the server's card across the whole width (it stopped at 900 px),
  *this one* beside its name, the ticks in the page's blue, and nothing refused said as the calm green box
  (*SELinux refused ai nothing on this server*) instead of a grey line.

## 1.0.97

- **SELinux: what it refuses, found out and sorted by what puts it right** (Settings → SELinux; after fake-igd's
  kit). Every AVC, USER_AVC and SELINUX_ERR since the machine started is read with the records of its event (the
  program, the whole path, the port), grouped by what was refused, put to audit2why and sorted: *a boolean*,
  *a label* (restorecon), *a port* (semanage port, never a port another service's type has), *a rule of ai's* (one
  rule in ai's own local module `ai_local`, each in an optional block), *not for a button* (security-sensitive types,
  executing, capabilities, unsafe classes, writes to generic types - each says why), *not ai's* (another program of the
  machine). What the policy loaded now allows is not counted. A refusal is ai's when it is ai's own program, a tool it
  runs, or a confined service it works with on one of ai's paths or ports.
- **Put in what is selected**: the fixable ones come ticked; the page sends only finding ids - root works out every fix
  again from the audit log; the confirm lists exactly what root will do; under enforcing too. What was put right is
  noted with its time and no longer counts; ai's local rules are listed, each with *Take it away*. Enforcing stays locked
  while something fixable or not-for-a-button is left.
- The report has the whole machine beside ai's part: `os/` - every process, boolean, port type and module, what was
  changed locally (`semanage … -l -C`, `semanage export`), every listening socket; and ai's local rules.
- Command line: `ai --selinux-look [--json]`, `ai --selinux-fix ID…|all` (lists what root will do, asks, or --yes),
  `ai --selinux-rules`, `ai --selinux-rule-drop ID`. `--uninstall` takes `ai_local` away with `ai_server`.
- When the audit log cannot be sorted, the card counts what was refused as before.

## 1.0.96

- **The pages stay with an upgrade that restarts them** (after fake-igd's upgrade kit). Root writes how far an
  upgrade is into one small file beside the pages (`/var/www/ai/.upgrade.json`, a dot name nginx never serves, 0644,
  written whole): the daemon when it starts one ("root checks the package"), install.sh at each of its steps
  (*Upgrading*, *Packages*, *The program*, *The pages*, *Starting*, *Done* - step N of M), and how it ended: done after
  *Done*, failed from its EXIT trap - also when it is killed (INT, HUP, TERM). An upgrade root's helper refused before
  install.sh ran is ended by the daemon from status.json. Only with `--upgrade` of an installed ai; a fresh install and
  everything else write nothing, and no write may stop the upgrade.
- PHP reads the file straight from disk: while the daemon does not answer, every call of the pages gets
  `503 {"upgrading": …}` ("ai is being upgraded to X - back in a moment") instead of "the daemon is not answering";
  `?api=upgrade-state` says how far it is and whether the daemon answers, without the daemon; the status carries it;
  `/healthz` says `maintenance …: being upgraded to X`, not `down`. Believed for 30 minutes while running, 10 after
  it ended; anything else in the file is as no file.
- One band under the header: *ai is being upgraded to X* - from, asked by, how long so far, a bar, the step and its
  words, and what it means now (the API restarting - not answering for N s; nginx and PHP restarting; asked again
  every two seconds). The pill says *being upgraded*; no red bar and no red words while it is expected. When it is
  done the page loads the new version by itself, once (never in a loop, never over settings not saved - then a
  link). Failed: a red band with the reason and *Open Upgrades*, hidden with ×. Settings → Upgrades draws the plan
  from the file while the daemon is away, and for an upgrade run by hand on the command line.
- The sign-in page says it too, from the file, and loads again by itself once the daemon answers.

## 1.0.95

- **Upload the missing authority** (Settings → Certificates and TLS, the card of the certificate; after plexmon
  2.9.8): when the intermediate cannot be fetched - no *CA Issuers* address, no way out, a private CA - only that
  authority is uploaded, never the certificate and its key again. The dialog names what is missing, takes PEM or a
  .cer / .crt / .der file (made PEM in the browser), refuses a key and an authority that did not sign the chain's
  last link (naming the one wanted); an intermediate goes into the chain in order, a root beside it - kept to check
  with, never sent. Each upload and check is written in the events.
- The chain's button is **Check the chain** when it is complete and **Complete the chain** (primary) beside
  *Upload the missing authority* when it is not; neither for a self-signed certificate. The action answers with
  `complete`, never `ok: false`.
- The card says what the server found, in its words: *complete - 2 certificates up to …*, *(fetched: …)*,
  *- a private root: only clients that trust it take it*, *incomplete - the authority … is not sent and could not be
  completed (why)*, *it leads to …, a root the system does not trust*, *self-signed - no chain*. Green and red really
  are green and red on the card now.
- What nginx sends **now** is checked too (the file in place, by its mtime, the system's roots, nothing fetched) -
  a certificate put in before any of this shows red until its chain is complete.
- From a *CA Issuers* address the certificate whose subject is the issuer wanted is taken (up to 256 kB, PEM, DER or
  PKCS#7), kept a day. Only a refusal of the chain by a client that fetches nothing is an alert; any other failure
  of the check from here is said, no more.

## 1.0.94

- **The chain of the certificate in place is looked at by itself**: 90 s after the start, then every 6 hours - also
  for a certificate put in before 1.0.93, whose card said only *Chain: 2 between it and the root*. Complete: the card
  gets *Chain: complete (… up to …)* and *Checked from here*, and nginx is not touched. A link missing: put in again
  once for that certificate, the intermediate fetched from *CA Issuers*. Not trusted by a client that fetches nothing
  (also when a root left the system's list later): an event and the notice at the top.

## 1.0.93

- **The certificate of the pages is sent with its whole chain, and checked as other programs check it** (after
  acme 1.0.88's note for isemon). A certificate uploaded without its intermediate is trusted by browsers - they
  fetch the missing link themselves - and refused by curl, Python, Java, Go, acme's pairing, monitoring agents and
  mobile apps ("unable to get local issuer certificate"). Before any certificate goes into nginx - uploaded, from
  a request, from ACME, from acme push, its ECDSA twin too - its chain is checked against the system's roots; a
  missing intermediate is fetched from the certificate's *CA Issuers* address (DER, PEM or PKCS#7, at most 4 steps,
  through the proxy where ACME's use of it is on), kept with it and sent by nginx. The root itself is never sent.
- The card in Settings → Certificates and TLS says *Chain: complete (2 certificates up to …)* in green, or
  *incomplete - the intermediate … is not sent* / *the root … is not among the system's roots* in red, with
  *Complete the chain*; a root of your own given with the certificate is said as such.
- **Checked from here**: after nginx has reloaded, ai connects to itself as a client that fetches nothing (the
  system's roots and the roots given with the certificate), waiting first until nginx answers with the new
  certificate. Not trusted is an event and a notice at the top of the pages, not silence.

## 1.0.92

- **SELinux report**: `processes.txt` came out empty - `ps -eZo label,...` is refused by procps-ng on EL9 ("can not
  use output modifiers with user-defined output") and the filter threw the error away. Now `ps -eo label,...`, and
  what ps says when it fails stays in the file.

## 1.0.91

- **SELinux** (Settings → Access → SELinux, after otp's): how it stands - enforcing, permissive, disabled, and what it
  is after the next restart - what ai needs of it (its own module `ai_server`, the labels of `/run/ai` and the API
  token the pages read, `httpd_can_network_connect`, the ports of a local database or of nginx outside the usual ones)
  and what it refused since the machine started, or since ai's needs were last put in. Switched on step by step, never
  by itself, each step confirmed and written in the events: *Make it ready* (disabled → permissive at the next start,
  every file labelled then), *Put in what ai needs*, *Switch to enforcing* (only once nothing is missing and nothing
  was refused; what is still missing is put in then, but never enforced in the same step), *Back to permissive*.
  *Download the report*: what SELinux says here as one .tar.gz, nothing secret in it, for whoever writes the module.
  Enforcing with something missing goes to Settings → Upgrades → To be done by hand. On the command line
  `ai --selinux-check [--json]`, `ai --selinux prepare|enforce|permissive`, `ai --selinux-report [FILE]`.
- `deploy/ai_server.cil`: `/run/ai` labelled for the pages (`httpd_var_run_t`), and systemd may hand it over. Put
  into the policy by install.sh and every upgrade (only when it changed), taken out by `--uninstall`; on dnf systems
  the SELinux tools and auditd are put in and started.
- **Trusted roots of the system** (Settings → Certificates and TLS): certificate authorities of your own - a company's
  root, an intermediate - put into the trust of the whole operating system (curl, dnf, git, LDAPS, Claude Code's and
  ai's own connections), the system's own way: `update-ca-trust` on RHEL, AlmaLinux and Rocky, `update-ca-certificates`
  on Debian and Ubuntu. The distribution's list stays as it is and keeps coming with the system's updates. ai writes and
  removes only its own `ai-<sha256>.pem|.crt`; what somebody else put there is shown and left alone. Each one is read by
  openssl first: a server's own certificate (CA:FALSE), one that may not sign certificates, a private key are refused;
  run out, weak keys, SHA-1, an intermediate without its root are said. The add dialog checks as you type or read a
  file (PEM, or DER from a .cer). Brought to the machine at once, at the start and every half hour; the tool runs only
  when something changed and each one is looked for in the system's list after it. On the command line
  `ai --os-roots [--json]`, `ai --os-roots-add FILE|-`, `ai --os-roots-remove SHA256`.

## 1.0.90

- **Clear for "Done lately"** in Settings → Upgrades → To be done by hand: at the right of its heading, it empties exactly
  the rows the page shows - a row come meanwhile stays, and what is still to be done is never touched; with the list
  empty the table and Clear are not drawn. Written in the events (who, how many); on the command line
  `ai --notices-clear-done`. The green *Nothing is to be done by hand* has its tick, and the time on each card is
  written as in the tables.

## 1.0.89

- **"To be done by hand" in Settings → Upgrades, as upsmon's**: one card, always there - green *Nothing is to be done
  by hand* when nothing waits - with the notices in it: ✕ for a step that is needed, a flag for one waiting for
  something, the command with *Copy*, when it goes, the time it came; *Look again* runs the checks at once, *Done* says
  it is done. Under them *Done lately*: what, how (done, by itself), who, when. Upgrades in the settings menu has a red
  badge with the count on its icon, seen with the menu shut too.
- A notice can wait for a file: `check: 'file:/a/path'` - it goes by itself once that file is there.

## 1.0.88

- **The alerts at the top of the pages are back as they were**: tmux missing, the certificate running out and a newer
  version are again in the yellow bar under the header, as before 1.0.85. Only what came with 1.0.85 - what a version
  needs done after it is installed, and SELinux no longer enforcing - is in Settings → Upgrades, with its count on
  Settings and Upgrades; the state pill turns red and opens Upgrades only for those.

## 1.0.87

- **The notices are in Settings → Upgrades**, not over every page: the top of the pages stays clear; the Settings tab
  and Upgrades in its menu carry a count (red while a step is needed), and the state pill (*running - a step is
  needed*) opens Upgrades with a click. Somebody who is not an administrator sees at the top only what stops their own
  work (tmux missing).

## 1.0.86

- **The notices look as isemon's**: a card each under the header instead of one bar - red with an ✕ for a step that
  is needed, yellow with a ⚠ to mind, blue to know - with the title, what happened and why, where to run the command
  and the command in a box with *Copy*, and when the card goes by itself. On the right: *Open it* (the place in
  Settings), *Done* (for one a version added) and *Not now* (hidden in this browser for 8 hours).

## 1.0.85

- **One system for what needs the administrator** (docs/notices.md): a version that needs something done after it is
  installed - a step on the command line, SELinux it changes, a restart by hand - lists it in the code, and once the
  daemon runs on it the pages say so plainly: a red bar under the header (yellow to mind, blue to know), the state
  pill red (*running - a step is needed*), and *How to fix it* - what and why, the command to run as root (copied with
  a click), the place in Settings, and *Done*. The same on the command line: `ai --notices` (exit 1 while a step is
  needed), `ai --notice-done ID`, `ai --status`, the console; and in the events. A notice is added once, after an
  upgrade only (not on a fresh install), and stays until said done or until its check finds the cause gone.
- The checks go through it too: tmux missing, the certificate running out (red within 3 days), a newer version, and
  new: **SELinux no longer enforcing** when it was - by an update, by hand or by another program.

## 1.0.84

- **The load is there at once when a page comes back**: the first ask after the watching had ended (a page left and
  opened again, a tab back after a while, a restart of the daemon) waited for two new readings. It is answered at once
  now with what was watched last - the numbers and the two minutes of the graphs, from memory or from the row in the
  database - shown dimmed, and the page asks again 1.5 s later for the new reading.
- **The graphs slide together**: the right edge of every graph is the daemon's "now" of the answer, not each one's
  newest reading, so every graph - of every node - is on one time line and slides in step.

## 1.0.83

- **The passkeys of an account look and work the same everywhere**: in My account and in the card of an account
  (Settings → Accounts) the same section - the words, the table, and on each row a pencil and a bin. The pencil
  renames the passkey in place (Enter or leaving the box keeps it, Esc does not); *Add a passkey of this device* is
  below the table in both. In the card of somebody else's account Add is there but off, saying why: a passkey is made
  by the device of the one it signs in, in their own My account.

## 1.0.82

- **The graphs of the load slide all the time**: the slide of 1.0.81 (an SVG `animateTransform`) moved one step and
  then stood still until the next reading - a reading is up to 5 s old when a page gets it - and some browsers did
  not run it at all. Now each graph's SVG group slides by one CSS animation at the pace of time, six steps long so it
  never waits, begun as far in as the newest reading is old; a new reading draws it one step further and the slide
  goes on without a jump. Nothing is redrawn on a timer. With *reduce motion* set in the system it does not slide.
- The first ask after the watching starts has its numbers at once (it waited for the watcher's first reading).

## 1.0.81

- **The load is watched by the daemon, once for every page**: while a page shows the meter the daemon reads the
  kernel's counters once every 5 s - however many pages, tabs and devices ask, they all get that one reading - and
  keeps the last two minutes in one small row of the database for this node (meta `load:<node>`), written every
  5 s only while it is watched. Nobody asking for 45 s (every page closed, the meter switched off), the watching
  ends by itself. The graphs come from the daemon's own two minutes, so they are the same on every page and outlive
  F5 and a restart of the daemon.
- **The graphs slide smoothly**: each graph moves by one SVG animation until the next reading; nothing is redrawn
  on a timer, only when a reading comes (every 5 s). A stretch nobody watched breaks the line instead of being
  filled in.

## 1.0.80

- **The performance meter can be switched off for the whole server**: Settings → About → *The performance meter in
  the header* (on by default; `ai --set perf_meter=false`). Off, it is gone for everybody: the header has no place
  for it, My account says it is off instead of offering its looks, and `GET /api/load` is refused - the server reads
  nothing for it. A page open while it is switched off stops asking at its next try.
- **Off means nothing at all**: an account that has it off (the default) runs no timer for it in the page any more -
  before, an empty one ticked every 3 s, asking nothing; switched off in My account, what the page held of it is
  dropped too.

## 1.0.79

Fixes of the load in the header, found when it was taken into another application:
- **Every core has its temperature**: the temperature of `coretemp`'s "Core N" went to the logical processor
  numbered N, so with hyperthreading (cpu2 is the second thread of core 0), with cores numbered with gaps (Core 0,
  1, 4, 5...) or with two processors, part of the cores had none. Each logical processor gets the temperature of
  the core it is on now (`topology/core_id` and `physical_package_id` in /sys).
- **Free space only of the kernel's own filesystems** (ext4, xfs, btrfs, zfs...), which answer from memory: a
  network share (NFS, SMB) gone away made `statvfs` hang and every ask of the load with it; FUSE and FAT may go to
  the disk for it. They are not listed in the panel now.
- **Bars say exactly what they show**: nothing at 0 % (an idle core, disk or filesystem had a bit of a bar beside
  its "0 %", and a ring a dot); the bar of a process is its real share - one core, or of the memory in use - not its
  share of the busiest process, so a process at "0 %" no longer has a third of a bar.

## 1.0.78

- **The graphs of the load survive F5**: the daemon keeps the readings of the last two minutes that pages asked for
  anyway (a list of a few dozen numbers, no reading made for it), and a page loaded again - F5, a new tab, another
  device - draws its graphs from them and goes on, rather than starting from nothing. A stretch nobody looked at is
  not filled with made-up numbers: the graph starts after it.

## 1.0.77

- **The load of the server in the header is off until switched on**: an account that has not picked a look sees
  nothing beside *running*, and its pages ask the server nothing for it. It is switched on in My account, by
  picking one of the looks (with a graph, pills, one line, rings); an account that had picked one keeps it.

## 1.0.76

- **The start page on an iPad held upright**: the start card took only the window's height and the tiles of
  the ended chats ran out of it, over the list of terminals under it. It grows with what is in it now and the
  page scrolls as one - as it does in a wide window since 1.0.69.
- **docs/ipad-and-passkeys.md**: how signing in with Face ID / Touch ID (passkeys), the icon on the home screen,
  the whole screen on an iPad and the rest made for it (the keyboard on the screen, turning it, pointing and
  tapping) are done - the API, every check, the code of the pages, the looks with pictures - to be taken into
  another application.

## 1.0.75

- **The looks of the load are picked from cards in My account**, as the colours of the terminals: every choice
  shows what it really looks like - the header's numbers (with graphs, pills, one line, rings, not shown) and the
  details (tiles, table, map of the cores, one wide panel, only a short tip) - drawn by the same code from sample
  numbers of a server with sensors. A click picks it and it is kept at once.
- The tiles of the cores no longer break their frequency and temperature onto two lines on machines with many
  cores.

## 1.0.74

- **The details of the load have four styles to choose from**, in My account (*Its details, when a number is
  pointed at*): **tiles** (a card for each core, as in 1.0.73, the default), **a table** (a row for each core
  with its bar, %, frequency and temperature, as htop - best for many cores; the disks as a table), **a map of
  the cores with rings** (the whole processor and its temperature as rings, each core a coloured square, the
  disks as cards and the filesystems as rings) and **one wide panel** with the processor, memory, disks and
  network side by side (two columns on a narrow screen). Or **no details** at all: the numbers then only show
  their short tip, and nothing more is read from the server.

## 1.0.73

- **The load in the header opens into details.** Pointing at a chip (a tap on an iPad, Enter from the keyboard)
  opens a panel under it: the last two minutes larger, and for **CPU** each core with how busy it is, its
  frequency and temperature, the processor's model, load, uptime, the processes taking most; for **RAM** what is
  in use, free for programs, cache, shared, swap and the processes holding most; for **disks** each disk with
  read/write, how busy it is, its size, model and temperature, and every filesystem with how full it is; for
  **network** each card with its state, speed, traffic now and since start. Temperatures come from the kernel's
  hwmon (coretemp, k10temp, zenpower, nvme, drivetemp), else from thermal zones; a machine without sensors (a
  virtual one) says so. The details are read only while a panel is open, and it closes on leaving it or a tap
  elsewhere.
- The header's look **with a graph of the last two minutes** is now the default (My account still chooses).
- The chips in the header keep their width: every number has a fixed place, so the graphs and chips beside it
  no longer jump as the numbers grow or shrink (in all four looks).

## 1.0.72

- **How busy the server is, in the header beside *running***, for an administrator: CPU, RAM in use, the disks
  read and written, the network in and out - every 3 s while the page is shown, nothing while it is hidden or
  paused. The daemon reads the kernel's counters in /proc only when asked (no thread, nothing kept but the last
  counters; pages asking within the same second share one reading - 200 asks take a third of a second). The
  disks are counted whole (no partitions twice, no loop devices), the network as its cards (no loopback, no
  bridges of containers). A pointer on each says more: the cores and the load, the swap.
- **Four looks to choose from** in My account (*The load of the server in the header*): pills with a bar (as it
  comes), one plain line, with a graph of the last two minutes, with rings - or not shown. A bar turns yellow
  from 70 %, red from 90 %. On a narrower screen the graphs of the disks and the network make way; under
  700 px the numbers make way for the rest.

## 1.0.71

- **Passkeys are off until switched on** (Settings -> Signing in -> *Signing in with a passkey*): until then the
  sign-in page offers none, none can be added in My account (it says where to switch them on) and none is taken.
  Passkeys added under 1.0.70 are kept, and work again once switched on.

## 1.0.70

- **Signing in with a passkey - Face ID, Touch ID, Windows Hello, a security key (WebAuthn).** *My account ->
  Passkeys -> Add a passkey of this device*, signed in with the password: the device keeps it (an iPad and an
  iPhone in the iCloud Keychain, so the other Apple devices of the same Apple ID too). The sign-in page then
  offers *Sign in with a passkey (Face ID, Touch ID)*: no name, no password - the face, the finger or the PIN of
  the device. It works in Safari and in ai added to the home screen.
- **With the second step on, a passkey counts as it** (*A passkey counts as the second step*, Settings ->
  Signing in, on by default): a passkey that checked the person is both steps at once; off, the code is asked for
  after it. *Signing in with a passkey* switches the whole of it off.
- The server keeps only the public half of each passkey and checks every signature with openssl: ES256 (Apple,
  Google, most keys), RS256 (Windows Hello), EdDSA. Refused: a passkey that did not check the person, one of
  another name or page, an answer used twice, a counter that went back (a copied key), a passkey taken away.
  Each account lists and takes away its own; an administrator anybody's (Accounts -> the account), and
  `ai --passkeys [NAME]`, `ai --passkey-forget ID|all` on the server. Every addition, removal and sign-in is an
  event. Only on the pages reached by their name over HTTPS with a trusted certificate. Signing in with the
  password is as it was.

## 1.0.69

- **The start page of Terminals in a low window (an iPad's Safari, with its address bar and tabs).** The card
  stayed as tall as the window while what is in it - the box to start, the folders used lately, what is going on,
  what ended lately - ran out below it, and the page scrolled with the card and its contents moving apart. The
  card now grows with what is in it, the list's rail with it, and the page scrolls as one. A window tall enough
  (a PC) looks as before; an open terminal is as tall as the window, as before.

## 1.0.68

- **On an iPad the full-screen button puts Safari into full screen too**, and the X (or Esc twice) brings Safari
  back as it was. The terminal covers the whole window and Safari is asked to give the whole screen to the page,
  so its address bar and tabs go away. Safari takes that back by itself when its keyboard on the screen comes up
  (with a Magic Keyboard or another hardware keyboard it does not): the terminal then stays over the window, only
  Safari's bars come back.
- **ai on the home screen.** *Share -> Add to Home Screen* on an iPad or a phone now makes an app of it - its own
  icon, opened without any bars of the browser at all, the keyboard on the screen included (a manifest, the
  icons, `apple-mobile-web-app-capable`). It signs in once on its own.

## 1.0.67

- **Settings -> Claude Code: Check it, Update and Install work with the folders limited.** With *The folder of
  the chats* set (or *Files only in the folder of the chats* on), they were refused - *outside the folders this
  account may use* - for they run in the account's home, where Claude Code lives. They are an administrator's
  upkeep of Claude Code, not a chat, and are no longer kept to those folders; started again from the list, they
  still are not. *Sign in* opens a session of Claude's, so it keeps to them: it starts in the folder of the chats,
  else in the first folder the account may use. Chats and shells are kept to the folders exactly as before.

## 1.0.66

- **The keyboard on an iPad's screen no longer covers the terminal.** The page is as tall as the window and the
  on-screen keyboard only lay over it: the bottom of the terminal - where the cursor and Claude Code's prompt are
  - and its keys (Ctrl, Esc, the arrows) went under it. While it is up and a terminal is open, the page is as tall
  as what the keyboard leaves, the header and the tabs make way, and the terminal is fitted to the rest; with the
  keyboard down everything is as before. A hardware keyboard (Magic Keyboard, Smart Keyboard) changes nothing.
  Checked on an iPad Pro 11 on its side and upright.

## 1.0.65

- **An iPad turned with a terminal open keeps it in sight.** On its side it is wide (the list beside the
  terminal), upright it is narrow (the list and the terminal in turn) - and turned upright, the open terminal
  vanished behind the list. The turn is noticed now: upright the list makes way for the open terminal, on its side
  again it comes back as it was. After every turn the terminal is fitted again a few times as Safari settles on
  the new size, over the whole screen too. Checked on an iPad Pro 11 both ways, over and over.

## 1.0.64

- **The terminal over the whole screen on an iPad (and an iPhone) no longer closes at once.** Safari there gives
  an element the whole screen only until a keyboard comes up - and the terminal takes the keyboard at once - so
  it left the whole screen again by itself, and the page took that for the person leaving it. On iPadOS and iOS
  the terminal now covers the whole window instead, sized to what the on-screen keyboard leaves of it; the X in
  its corner (or Esc twice) brings it back. Elsewhere the whole screen is the browser's as before; and a
  browser leaving it by itself within moments no longer closes it - the terminal stays over the whole window.

## 1.0.63

- **`ai --get KEY`**, beside `ai --set KEY=VALUE`: a setting's value as `--set` takes it back (`true`/`false`,
  numbers, text), alone on its line for a script. Several (`--get a --get b`, or `--get a,b`) or a group
  (`--get 'acme_*'`) are `KEY = VALUE`; `--json` adds the default and where the value comes from (saved,
  config.json, the default). A password shows as dots and its last two characters, another secret as
  `(hidden)`; a key that is not a setting says which ones it may have meant, and ends with 1.

## 1.0.62

- **Upload takes a ZIP**: the one *Download -> both* gives (two PFX, or two PEM with their keys), or one of your
  own with PEM, CER/DER or PFX files in it, in folders too. What is in it is taken as if each file had been
  chosen: a pair is put in as a pair, one certificate as one. Refused, with nothing changed: a ZIP locked with a
  password, one that cannot be read, one with nothing of a certificate in it, more than 20 files or a file over
  1 MB. Two PFX files chosen together still make a pair, as in 1.0.61.

## 1.0.61

- **Dual certificates (an RSA one and an ECDSA one beside it) downloaded and uploaded whole.** *Download* gave
  out only the RSA certificate and its key; the ECDSA one and its key never left the server. With a second
  certificate there, the window asks *Which certificate*: the RSA one, the ECDSA one, or both - a ZIP with the
  two files, each with its own chain and its own private key, in every form (PEM, CRT, DER, PKCS#7, PFX, PEM
  with the key, the key alone), locked with the same password. With one certificate nothing changes.
- *Upload* takes a pair: two certificates of the same names, an RSA one and an ECDSA one, each with its key, as
  PEM in any order or as two PFX files with one password. Each key is matched with its own certificate, and they
  are put in as the Automatic certificates' *both* are - nginx offers the ECDSA one to the clients that take it,
  the RSA one to the rest. Refused, with nothing changed: two of the same key type, other names, more than two
  keys, a key without its certificate. One certificate is uploaded as always (and takes the place of a pair).

## 1.0.60

- **Certificates from acme: a click on a tile copies it.** The pairing code, the address for acme, this
  server's id and its sealing key - on the card and in *Pair with an acme* - go to the clipboard with one click
  (the tile lights up, a toast says what was copied), ready to paste into acme's target.

## 1.0.59

- **Certificates from acme: changes wait for the save bar.** *Take certificates from acme*, *Take certificates
  of other names* and *Forget it* no longer act at once: changed, the save bar comes up at the bottom (*1 change
  not saved yet*), *Save the changes* does them, *Put them back* throws them away. An acme to forget is struck
  through until then, with *Keep it* beside it. Pairing (a code shown once) and pasting acme's key stay actions
  of their own, as before.

## 1.0.58

- **Certificates from acme (acme push, protocol 1)**: your acme - the certificate manager - can give this server
  its certificate and renew it by itself. Settings -> Certificates and TLS has a new card *Certificates from
  acme*: switched on (off until then), *Pair with an acme* shows a one-time code (15 minutes, five wrong tries end
  it) or acme's key is pasted; the paired acmes with *Forget it*; *Take certificates of other names*; what acme
  sees here (the slot `node:HOST`, its names, the certificate it has, who looks after it) and the last push.
  The pages answer acme's four requests (`?api=acme-push-hello|pair|inventory|install`) before any session:
  every request signed with acme's Ed25519 key (time within 300 s, nonces kept in the database), the
  certificate's key sealed for this server alone (X25519 + HKDF-SHA256 + AES-256-GCM). A certificate pushed -
  with its twin of the other key type where acme sends one - is checked (fingerprint, key, valid now, the name)
  and put in exactly as an upload is: nginx -t and reload, the Automatic certificates leave it alone (*Look
  after it* gives it back), an event for each. The same one again is `already`, nothing reloaded.
- **Only one more way - nothing existing changes** (the document's chapter 0): upload, a request, self-signed,
  the Automatic certificates (ordering and renewing), the TLS settings, the export, backups and the command
  line work as before, with push off and with push on and paired, and replace a pushed certificate as they
  replace any other; switched off, the certificate stays where it is. No existing function is redefined - a
  check now refuses any name defined twice in ai.py.
- On the command line: `ai --acme-push [status|on|off|pair|stop]`, `--acme-push-key KEY`, `--acme-push-forget
  KEY_ID`. The crypto is the `cryptography` module where it is installed, else plain Python; both are checked
  against the document's test vectors.

## 1.0.57

- **Move to another database…, its first step on a server**: running on PostgreSQL or MariaDB, the card of the
  engine in use said *in use now - another server or database of it* in one long label that ran out of the card.
  It says *in use now*, and under it, wrapped inside the card, that another server or another database of it can
  still be chosen. Labels in the cards wrap rather than run out of them. Checked at 1500, 900 and 390 px.

## 1.0.56

- **The database's settings are back on Settings -> The database, and work beside the wizard.** How the database
  in use is reached - server, port, database, account, password, encryption and its authority, the wait - is
  shown and changed there again: saved, it is tried first (nothing changes if it cannot be used), written into
  config.json, and the daemon starts again on it while the page waits and loads again. Pointing it at another
  database that holds nothing of ai is refused - that is a move, and would leave everything behind. *The
  database* (the engine) is shown but not changed there: the button under it opens *Move to another database…*,
  which is for the moves alone. The wizard starts from what the settings say (server, account, encryption, the
  wait), so the same server is one Next away.

## 1.0.55

- **Move to another database…, its looks put right**: what the account said when it could not get in no longer
  runs into the administrator's boxes below it; the line under the bar while it moves wraps instead of being cut
  off with "…"; a move that stopped shows a red bar and the step it stopped at, not an empty bar saying
  "starting"; long notes and addresses wrap inside their boxes; on a phone the buttons at the bottom share the
  width instead of leaving one on a line of its own. Everything in it, and on the card *Which one it is*, is in
  Czech now (Close, Reached, the plan's first step, the steps as they go, the card's own words). Checked at
  1500, 1200, 900, 600 and 390 px: nothing over anything, nothing out of its box.

## 1.0.54

- **Settings -> The database -> Move to another database…: a wizard** in place of the four buttons (Try it, Set
  it up, Carry everything across, Start using it) and the address boxes above them. Step by step, with Back and
  Next: *Where to* (the file on this machine, MariaDB, PostgreSQL - the one in use marked, a missing driver said),
  *How to reach it* (server, port, database, account, its password - empty: one is made -, encryption, its
  authority, the wait), *What is there* (reached or not, what it holds; an administrator of that server asked for
  only where the database and the account are not there yet, used once and kept nowhere; a database already
  holding records of ai is emptied only when agreed), *Go* (what will happen, switch over at the end or not) and
  *Moving*: one job makes a copy here, makes and empties the other one as agreed, carries everything in, counts
  every table on both sides (a move that lost anything stops there), writes the address into config.json and
  starts the daemon again on it - the page waits for it and loads again. Until the switch nothing here changes
  and nothing is written into config.json, so a failed move leaves the installation as it was.
- `ai --db-move sqlite|mariadb|postgres` (`--db-host`, `--db-port`, `--db-name`, `--db-user`, `--db-admin` with
  `AI_DB_ADMIN_PASSWORD`, `--empty-first`, `--no-switch`, `--yes`), and in `ai --console` under Data.
- Tested every way: SQLite -> PostgreSQL -> MariaDB -> SQLite -> MariaDB -> PostgreSQL -> SQLite, into empty and
  into used databases, with a new account made and with one already there; refused or stopped with nothing
  changed: the database in use, a wrong administrator password, a used database not agreed to be emptied, an
  unknown engine.

## 1.0.53

- **Every saved password shown as dots and its last two characters, to an administrator, everywhere; typed,
  only dots.** The proxy's password and the ACME DNS API secrets (TSIG secret, acme-dns, Cloudflare and deSEC
  tokens) were drawn as plain text boxes - what was typed showed as it was typed; they are masked now like the
  others. `ai --settings`, `ai --set` and the console's settings show a saved password the same way (dots and
  its last two) instead of `(hidden)` or its sealed form, and the console asks for it unseen. The passphrase of
  an exported configuration is typed into the same masked box. Everyone but an administrator still sees
  nothing of them.

## 1.0.52

- **Settings -> Backups -> Try the newest** (as otp's 1.0.169): the newest backup of this server is fetched back
  from the first destination switched on, opened with the password of the backups, every file checked against
  its manifest, the copy of the database read to its last line (the accounts counted against the manifest, an
  administrator there to sign in with), the secrets sealed in it tried against the key in it, config.json read -
  and the newest nightly copy here read through too. Nothing is put back. The top of the page says *Tried: can
  be put back* or *NOT GOOD*; a new card *Backups tried* lists each try with every check (one taken off, or the
  list cleared - the backups stay). *Try the backups* (new setting): only by hand, after every backup (the one
  just sent), or once a week. On the command line `ai --backup-try` (`--rbackup-verify`), in the console under
  Data, and in `ai --backups`.

## 1.0.51

- **A password saved stays saved on the page** (Settings, the save bar): what was saved was left among the
  changes, so a password - shown as dots once saved, never as what was typed - kept *1 change(s) not saved yet*
  for ever and the page was not drawn again; on Backups the top still said *NOT locked - set the password*,
  though the password was saved. The saved ones are forgotten as changes now, the page is drawn again, and
  Backups shows at once whether its backups are locked and when the next one goes.

## 1.0.50

- **No more kernel notices over the ai console** (as otp's 1.0.210): every `systemctl daemon-reload` - each
  dnf update touching units, ai's own install - has systemd's generators log lines such as
  `/etc/rc.d/rc.local is not marked executable, skipping` to the kernel's log, and where the console log level
  is 7 the kernel printed them over the console on tty1. install.sh (install and every upgrade) now writes
  `/etc/sysctl.d/80-ai-console.conf` with `kernel.printk = 4 4 1 7` - errors only on the console, RHEL's own
  default; `journalctl -k` keeps everything - unless `kernel.printk` is already set by hand elsewhere, which is
  left alone. `--uninstall` takes the file away. rc.local is not made executable.

## 1.0.49

- **Settings -> Proxy: each use switched on by itself**, all off at first (the proxy itself too) - with none on,
  nothing ai does goes through it. The uses: *The updates of ai*, *The system updates* (dnf, apt), *ACME - the
  CA*, *ACME - the DNS APIs* (Cloudflare, acme-dns, deSEC), *The SMS gateway (HTTP)*, *The SMS router
  (Teltonika)*, *The terminals and Claude Code* (HTTPS_PROXY, HTTP_PROXY, NO_PROXY in the new claude and shell
  terminals) and *Installing and updating Claude Code*. A use that is off goes straight, never through what the
  environment of the service says. Mail (SMTP), the backups (FTP, SFTP, SMB), NTP and the database are not HTTP
  and always go straight. *Try it* asks through the proxy as saved, whichever uses are on.

## 1.0.48

- **The proxy is for the updates only** (Settings -> Proxy): the new versions of ai (looked for and fetched) and
  the system updates (dnf, apt) go through it, nothing else. The SMS gateway, ACME's CA and its DNS APIs go
  straight again, as before 1.0.47 - a proxy that is down or refuses can no longer stop anything ai does but
  its updates. *The SMS gateway through it too* is gone; the page and *Try it* say what the proxy is for.

## 1.0.47

**Settings -> Proxy, as otp's** (off until switched on): an HTTP proxy, with a user name and a password kept
sealed, for what ai asks of the web - the new versions, the SMS gateway, the ACME CA and its DNS APIs - and for
dnf or apt fetching the system updates (handed to the update's job in a file only root reads, never on a
command line). Names, domains and nets reached straight are listed (`.example.cz`, `10.0.0.0/8`); the system
updates and the SMS gateway can each be left out of it. Mail and the database never go through it, nor does
what the environment of the service says.
- **Try it**: an address asked the way ai asks the web - through the proxy, or straight where none is set or
  the address is in the list - and the way it went drawn: this server, the proxy, the address, each link green
  or red, then every step with its time (the name looked up, the connection, the tunnel, TLS and the
  certificate, the answer).
- `ai --proxy-test [URL]`; the menu has it under *Server*, after Network, as otp's.

## 1.0.46

**Upgrades and maintenance, as otp 1.0.197 (without high availability)**
- *Settings -> Upgrades and maintenance -> The nodes*: the server, its version, when it was heard from, and
  whether it is **in service** or **in maintenance** (why, by whom, when) - with *Maintenance* / *Back in
  service*, asked first with the reason for the events.
- **Maintenance**: this server out of service - `/healthz` says `503 maintenance HOST` (and `ok HOST` otherwise),
  so a monitor or a load balancer leaves it alone; nobody but an administrator signs in and no new terminal is
  started but an administrator's; the terminals that run go on, and so do these pages. The header says *in
  maintenance*. An upgrade from these pages takes the server out first and brings it back once the new version
  runs (or the upgrade failed); one taken out by hand stays out until brought back.
  `ai --maintenance on|off|status [--why ...]`; the console has it under Upgrades.
- *What root said last* folded until opened (a long log pushed the rest down); *From the web*: its settings in
  otp's order and words (*Look for a new version every day*, *Where new versions are looked for*, *Offer going
  back to an older version*), ai's own auto-upgrade after them.
- **The settings menu in otp's groups and order**: *Access* (Accounts, The sign-in page, Certificates and TLS,
  Automatic certificates, Firewall and access, SSH keys of root), *Server* (Network, Time, Restart and power
  off), *Data*, and *Monitoring and updates* (System updates, Upgrades, About).

**Automatic certificates -> In your DNS** across the whole width again, each column a fixed share of it: the
same on a reload and after *Check DNS* (the last column's words changed and the columns were shared out anew).

## 1.0.45

- **Automatic certificates -> In your DNS**: room between the columns - the table no longer packed them against
  each other; each copy button still right after its text.

## 1.0.44

- **Automatic certificates -> In your DNS**: the table stretched across a wide screen and left wide gaps between
  each record and its copy button. It is as wide as what is in it now: every text as wide as it needs, its copy
  button right after it, one under the other.

## 1.0.43

- **Automatic certificates -> In your DNS**: the copy buttons flickered at every refresh of the page - they
  were lined up by measuring the text after it was drawn, so each redraw showed them out of line first (and a
  redraw merged into the page never lined them up at all). They now have narrow columns of their own right
  after the record and the value: one under the other, right after the longest text, by the table itself.

## 1.0.42

- **A setting hanging on one that is greyed out is greyed out too**, on every settings page: with ACME off,
  *The TXT records go into* (and *Wait for DNS to carry it*, the deSEC fields...) stayed open, because the
  choice they hang on would have let them. It says why from the setting further up ("Not in use while
  Certificates from an ACME CA is off").
- **The CA's own certificate** is a memo two columns wide and two settings tall, a whole PEM in view in a
  small monospaced font (resizable), the settings beside it stacked as usual.

## 1.0.41

- **Automatic certificates exactly as upsmon's (4.1.7)**: the page's script is upsmon's own - the card (its tags,
  *For*, *Issued by*, *Keys*, *Good until*, *Last ordered*, *Ordered by*), the order going on, the TXT record by
  hand, *Back to the one before*, *Its name...*, *In your DNS* with its steps and *Check DNS*; the pane's words and
  the menu button too. Every setting has upsmon's name, help (with its `code` marks) and choices, in its order;
  *The CA's own certificate* is a box in its place in the grid, as upsmon's, not a whole row.

## 1.0.40

**Automatic certificates: the keys as upsmon's (4.1.6, 4.1.7)** - every key Let's Encrypt accepts
(https://letsencrypt.org/docs/integration-guide/):
- **The certificate's key:** RSA 2048, 3072, 4096 or ECDSA P-256, P-384 - and, the new default, **both**: two
  certificates for the name, RSA served by default and the much smaller ECDSA one to the clients that take it
  (*Both: RSA 2048 + ECDSA P-256 (advised)*, or *Both: RSA 4096 + ECDSA P-384*). The second order only signs:
  the name is already proven. nginx gets two `ssl_certificate` / `ssl_certificate_key` pairs (`ai.pem` and
  `ai-ecdsa.pem`); a certificate put in another way on Certificates and TLS drops the ECDSA one.
- **The account's key** (new setting): ECDSA P-256 (ES256), P-384 (ES384) or RSA 2048, 3072, 4096 (RS256) -
  never a certificate's key. A change makes a new account at the next order.
- The keys show on the ACME card (*Keys*), on the certificate (*Key*) and beside the account; the order's
  steps say which keys were made. *What the last order did*: the time one narrow column, the words beside it.
- A key chosen before is kept; one never chosen is *both* from the next renewal - *Order it now* for it at once.
- The second certificate's key never reaches the page.

## 1.0.39

**Automatic certificates (ACME), as otp's** - *Settings -> Automatic certificates*, off until switched on:
- The certificate of the pages ordered from **Let's Encrypt**, its staging, or another ACME CA (step-ca, an
  internal CA - its directory and its root given), and **renewed by itself** when fewer than 30 days (as set)
  are left - a CA giving short-lived certificates at a third of their life. Checked once an hour; a failed
  order is tried again after 6 hours. An account the CA no longer knows is made anew by itself.
- **HTTP-01**: nginx sends port 80's `/.well-known/acme-challenge/` to `acme.php`, which gives the answer kept
  in the database (put into nginx's file by itself on an existing install). **DNS-01** for a server the CA
  cannot reach: RFC 2136 (nsupdate with a TSIG key, kept sealed, in a file only for the moment it runs),
  Cloudflare, acme-dns, **deSEC.io** (free; its name servers asked straight until both have the record), or
  by hand (the TXT record shown, the order waiting for *It is in DNS*). *The TXT records go into*: a zone of
  its own, the name with one CNAME to it in your DNS. *DNS servers for ACME*: public ones to see what the CA sees.
- **The key of the certificate - every one Let's Encrypt takes**: ECDSA P-256 or P-384, RSA 2048, 3072 or
  4096 - or **both**, as Let's Encrypt advises: an RSA certificate by default and an ECDSA one nginx offers to
  the clients that can take it (two `ssl_certificate` pairs). The account at the CA has a key of its own,
  never the certificate's. Another key asked for orders the certificate anew.
- The card: what it has now, days left, the key, the last order step by step (*What the last order did*),
  *Try port 80* (asked as the CA will), *Order it now*, *Look after it* / *Leave it alone*, *Its name...*, and
  **Back to the one before...** - a certificate of your own replaced by ACME is kept and put back with its key.
  **In your DNS** lists what the name needs there, with the steps of the way chosen and **Check DNS**.
- *Certificates and TLS* says who renews the certificate; one uploaded or made self-signed there is kept -
  ACME does not replace it (asked first). Its TLS settings stay through every renewal.
- `ai --acme`, `ai --acme-order` (followed); the console: *The server -> The certificate of the pages*.
- Every order, renewal and failure is an event.

## 1.0.38

- **Backups to SMB on a machine smbclient sees no interface of**: smbclient stopped with *Could not determine
  network interfaces, you must use a interfaces config line* (an address with a /32 mask, IPv6 alone, no
  network interface it takes). It is asked again with the loopback as its interface list - a list only its
  NetBIOS broadcasts use, never the connection to the server - and goes on.

## 1.0.37

**Updates and restarts on a schedule, as otp's (1.0.164)**
- *System updates -> On a schedule* (off until switched on): a look for updates every day at a set time -
  for the card, nothing put in - and the updates put in by themselves in a window: only the security ones
  (`dnf --security`, `unattended-upgrade` on apt) or all of them, every day, week or month, restarted by
  itself where needed or the restart offered.
- *Restart and power off -> On a schedule*: the server restarted in a window, every week or month - only when
  an update left it waiting for a restart, or every time. Not while an update or a look for updates is going
  on: it waits for it.
- Each once in its window; one that cannot start is said in the events, not tried over and over.
- An update by hand can be the security updates only, too (*Which*).

## 1.0.36

- **System updates after a restart made by itself**: the server was restarted as asked (*Restart by itself when
  needed*), but the pane went on saying *ai needs a restart* - what the update had wanted was never let go.
  A restart wanted before the machine last started is taken as done now, and once it is back ai looks for
  updates again by itself, so the pane says how it stands after the restart.
- The update's end cleared only the count: *of them security* and *restart after the update* stayed as they
  were before it. They go with the rest now.
- The restart after the update came only while somebody had the pane open (what the update's job wrote was
  read in only then); the daemon reads it every 15 seconds now.
- *After the update* shows the choice of the last update when the page is loaded again, not always *Ask me*.

## 1.0.35

- **System updates: the restart on a line of its own**: *restart after the update* (or *restart needed*) stood
  beside the server's name and its other tags and ran out of the card; it is on its own line under them now.

## 1.0.34

- **ai on the newest Python there is**: the install and every upgrade - from the pages too - look for the
  newest `python3.X` the repositories offer (on AlmaLinux 9 python3.14, 3.13 or 3.12, whichever its 9.x has),
  put it in beside the system's own python3 (which stays: dnf runs on it) and move ai onto it - ai.service and
  the command `ai` both. A Python is taken only when it starts ai and has ssl, sqlite3 and termios; one that
  does not is passed over, and with none newer ai stays where it is. The database driver and colorama are put
  in for that Python (its own package, or pip). The choice is kept in /usr/local/lib/ai/python;
  `--python PATH` chooses one, `--no-python-update` keeps the one in use. Settings -> About shows which runs.
  ai is checked on Python 3.11, 3.12, 3.13 and 3.14.

## 1.0.33

- **PHP on the 8.3 stream, at 8.3.36**: the install and every upgrade put PHP on `php:8.3` now, not `php:8.2`
  (1.0.32) - 8.3.36 has the php2shell fix. An 8.0, 8.1 or 8.2 is moved up to it, an 8.3 brought to its newest
  build, a newer PHP without the fix moved to it as well; a newer one with the fix is kept. On EL 8, which has
  no `php:8.3`, it is `php:8.2` and its 8.2.35. `--php-stream X.Y` still chooses another.

## 1.0.32

- **PHP on the 8.2 stream, at 8.2.35**: on AlmaLinux / Rocky / RHEL 8 and 9 (PHP as AppStream modules) the
  install and every upgrade - from the pages as well - put PHP on `php:8.2`, whose 8.2.35 has the php2shell
  fix (CVE-2026-109618, CVE-2026-109619): an older PHP (8.0, 8.1) is moved there, and so is a newer one that
  does not have the fix yet (an 8.3 short of 8.3.36); an 8.2 is brought to its newest build. The stream is
  reset and enabled, every PHP package moved with `dnf distro-sync`, php-fpm restarted, and the version
  reached is said. A newer PHP that has the fix is kept; `install.sh --upgrade --php-stream 8.2` moves even
  that, `--php-stream 8.3` puts another stream instead, `--no-php-update` leaves PHP alone. ai's PHP pool and
  the guard against php2shell stay as they were.

## 1.0.31

- **Downloading the certificate, in the form wanted**: *Download* under Settings -> Certificates and TLS opens a
  window to choose it - the certificate alone as PEM, CRT, DER or PKCS#7 (.p7b), or with its private key:
  PFX / PKCS#12 (always locked with a password; AES-256, or 3DES and SHA-1 for an older Windows), PEM with the
  key, or the key alone (both locked with AES-256 when a password is given). The chain goes along unless
  switched off; *Make a strong password* makes one and puts it on the clipboard. A download with the key is
  written in the events, as a warning. It is there for the certificate nginx had before ai looked after it too.

## 1.0.30

- **The command line and the console caught up with the pages**: what came on the pages since 1.0.13 is in
  `ai` and `ai --console` too -
  `--new` with `--effort` and `--mode` (and the model of any version, in the console from a list);
  `--edit ID` (`--title`, `--model`, `--effort`, `--mode`, `--cwd`) - a chat's choices changed, it goes on with
  its conversation; `--forget ID|ended` - ended terminals off the list; `--usage [--days N]` - what the chats
  used and what it costs, by model, account, folder and chat; `--signin-art [NAME]`, `--signin-logo FILE`,
  `--signin-logo-forget` - the picture of the sign-in; `--db-ipv4 [only]` - where the database server listens,
  kept to 127.0.0.1. In the console: Terminals (change a chat, take ended ones off, what the chats used),
  Settings - The picture of the sign-in page, Data - The database server.
- **A terminal's last screen in the console** opened over the menus without its own screen; it has one now.

## 1.0.29

- **The picture chosen for the sign-in shown to everybody**: the page tells a visitor not signed in from
  elsewhere no more than the language - and left out which picture was chosen, so from any other machine the
  sign-in kept showing the default one (from the server itself it was right). It is told the picture now too.

## 1.0.28

- **The pages after the upgrade to 1.0.27**: install.sh put in the PHP files of the pages by a list of names,
  and 1.0.27's new one (`ai-art.php`, the pictures of the sign-in) was not on it - so after the upgrade the
  page answered HTTP 500. It now puts in every PHP file there is, and a check makes sure it stays so.

## 1.0.27

- **The picture of the sign-in, chosen as otp's**: Settings -> The sign-in page shows every picture the sign-in
  can carry, drawn for what ai is - a browser, a terminal, a chat, tmux panes, the devices it reaches, the spark,
  a tablet, a diff, folders, agents side by side, the usage, the keys - and none at all; pick one and Save.
  *Upload your own* puts the site's own picture there instead (PNG, JPEG, GIF, WebP or SVG up to 512 KB, an
  SVG with a script or a link out turned away); *Forget it* takes it away again. The choice is in the database,
  so it is in every backup and in the exported configuration, and the import puts it back.

## 1.0.26

- **nginx on IPv6 whenever the machine has it**: installed with IPv6 off in the kernel, nginx's file was written
  without its `[::]` listen lines, and IPv6 switched on later never got them. They are put in (or taken out)
  after every change under Settings -> Network and when the daemon starts, nginx tested first and reloaded.
  The firewall needed nothing: its rules are written for IPv4 and IPv6 alike already.
- **The database server kept to IPv4**: The database shows where a MariaDB or PostgreSQL server on this machine
  listens, and *Only IPv4 (127.0.0.1)* tells it to listen on 127.0.0.1 alone - nothing over IPv6, nothing from
  outside - and starts it again (MariaDB: a `bind-address` file of ai's; PostgreSQL: `listen_addresses`).

## 1.0.25

- **A chat's choices changed while it runs**: *Change it…* on a chat's right button, its ⋯ and under More - its
  name, working directory, model (any version), effort, permission mode and more words for Claude Code. Claude
  Code takes these only when it starts, so the chat is started again in its own tile and goes on with its
  conversation; a new folder gets the conversation's transcript too, where Claude Code looks for it. A shell
  can be moved to another folder the same way.
- Claude Code's own options a chat was started with (effort, tools, system prompt, agent...) are kept when it
  is started again; only the model, the permission mode and the words were.

## 1.0.24

- **Files only in the folder of the chats** (Settings -> Claude Code, shown once the folder of the chats is set):
  on, the Files tab, the files of a chat, downloads and uploads reach that folder and what is under it only -
  for every account, administrators too; the daemon refuses any other path, and a path from before opens the
  folder itself.
- **The Overview in two**: *The server* (the machine, who is signed in, lately) and *Claude Code - the chats*
  (what the chats used, by day, hour, model, account and folder, and every chat), each its own address -
  `#overview` and `#overview/claude` - kept on F5.

## 1.0.23

- **Alt codes in the terminals**: Alt held and digits on the numeric keypad type their character when Alt is
  let go, as Windows does - Alt+64 is @, Alt+nnn the old DOS code page (437), Alt+0nnn the Windows one (1252).
  The digits went to the terminal as Esc and a digit.
- **The right button pastes, as in PuTTY**: in a terminal the right button puts the clipboard in, and what is
  selected is copied by itself; Ctrl with the right button (or a finger held still) opens the menu. Under your
  account (Language and letters) the right button can open the menu instead, as before. The browser asks once
  whether the page may read the clipboard.

## 1.0.22

- The headings of the start page (*Folders used lately*, *Going on*, *Ended lately*) have their room above
  again: a rule of the empty terminal pane took it away and each stood pressed against what was over it.

## 1.0.21

- On the start page *Folders used lately* stands above *Going on*, next to the box whose folder it sets, with
  room under it; its heading is in Czech too.

## 1.0.20

- **Only the terminal, over the whole screen**: a button in the terminal's bar (four corners) - and on the
  terminal's right button - puts the terminal alone over the whole screen, no bar, no buttons. Where the keys
  can be locked (Chrome, Edge) Esc goes to the terminal and is held to come back; where an element cannot take
  the screen, the terminal covers the whole window and Esc twice comes back. A × shows in the corner when the
  mouse moves.

## 1.0.19

- **The terminals' colours as PuTTY's**: the palette of the terminals was the pages' own, light and soft - mc's
  blue panels came out pale. The classic VGA palette PuTTY uses is now the default, bold drawn in the bright
  colours as PuTTY does. Eight to choose from - classic (PuTTY), xterm, the Linux console, Tango, Solarized dark,
  Dracula, the pages' soft one, light - as swatches under your account (Language and letters) and under More
  in a terminal, kept with the account.
- **Ended lately on the start page**: under *Going on*, the last six that ended - the pinned ones first - each
  started again where it stopped, in its own tile, by a click; *all of them* opens the list with the ended ones.
  More room between the two.

## 1.0.18

- **Every ended terminal off the list at once**: *Take every ended one off the list (n)* on the right button
  of the list of terminals and of any terminal in it, asked first. The running ones are not touched, and the
  conversations of Claude Code stay under Conversations. One at a time is still *Take it off the list*.
- In Conversations the git branch of a conversation stands beside its folder: its tag lay over the folder's
  name.

## 1.0.17

- **One tile a conversation in the list**: before 1.0.16 picking a conversation up again started a new terminal
  each time, and with *with the ended ones* the list showed the same chat many times over beside the one
  running it. The terminals that held the same conversation are merged by themselves: the running one - else
  the newest - is kept, the ended copies forgotten. An ended tile is matched only by the conversation it was
  started with, never by a guess from the times.

## 1.0.16

- **A chat keeps its tile**: each chat with Claude Code is given its conversation's ID when it starts
  (`--session-id`), and ai keeps it. Picking a conversation up again (Conversations, the Overview, the chat's
  menu) goes back into the terminal that holds it - opened if it still runs, started again in its own place if
  it ended, with its name and its pin - instead of a new tile. *Start it again* and *Restart* go on with the
  chat's own conversation (`--resume`), not the folder's last one or an empty new one; a `/clear` or a
  `/resume` inside the chat is followed.
- **Close** in the terminal's bar: back to the start page, the chat goes on running on the server.
- **Every version of the models**: Fable 5.1 and 5, Opus 5.5 to 4.6, Sonnet 5.5 to 4.6, Haiku 5.5 and 4.5 by
  name, beside the families (always their newest) - in the new terminal dialog, the start page and Claude
  Code's settings.
- **F5 anywhere keeps the page**: a page opened at its address (Settings -> Network, Time, the Overview's usage,
  the Claude Code tab) asked for its data before the scripts that load it were there, and stayed empty.

## 1.0.15

- The ⋯ of a chat in the list of terminals is in the row's bottom right corner: at the top it lay over the
  chat's name and its state. The state (running, ended, open) is never cut short any more.
- The figures of the Overview's usage line up: each tile's figure on one line whatever its label wraps to, the
  tiles across the whole width, every number of the tables in one font with digits of one width.

## 1.0.14

- **The scroll bar moves with the history again**: Claude Code's full-screen look (now its default for many
  accounts) keeps its history to itself, where the bar beside the terminal could only be a jog wheel standing
  still. Claude Code is started drawing itself the classic way (`CLAUDE_CODE_DISABLE_ALTERNATE_SCREEN=1`), so
  everything it says is in tmux's history: the bar shows where you are, History shows all of it, a finger
  scrolls it. Settings -> Claude Code -> *Claude Code written into the terminal's history* (on) turns it off;
  `/tui` in a chat switches that one. Chats already running keep their look until started again.
- **The time zone is saved**: the Time pane is drawn again every 10 seconds, and a zone chosen in the list
  drawn before that went into a draft thrown away - the save put in the old one. The draft is refreshed in
  place now.
- **A window over a window goes back to the one under it**: choosing a folder from the new terminal dialog,
  and every question asked twice ("Delete it?"), opens over the dialog; Close or No returns to it as it was.
- **Where a chat may start, said where it is chosen**: the new terminal dialog says whether the folder of the
  chats limits it (or that it may start anywhere), with the way to Settings -> Claude Code -> *The folder of
  the chats*.
- The banner's link to a new version opens Settings -> Upgrades itself, not only Settings.

## 1.0.13

- **What the chats used, on the Overview**: every chat with Claude Code of the accounts you may see, with its
  answers, tokens (written, sent, cache) and an estimated cost at Anthropic's list prices; the same by day, hour
  of the day, model, account and folder, as cost or as tokens, over 7 days to a year. A chat opens in its
  terminal, or is picked up again with `--resume`; found and sorted by newest, dearest, longest. A Claude
  subscription is not billed by the token: the cost is there to compare by.
- **Even spacing in the Claude Code tab**: the account and project bar, the heading, each card and the row of
  tiles are 16 pixels apart everywhere - the tiles touched the card above them.

## 1.0.12

- **The right button anywhere on the list of terminals**, not only on a chat: a new Claude Code or shell, picking
  up a conversation, the ended ones shown or not, finding a terminal, the list kept open or hiding itself, read
  again. A finger held still does the same on a tablet.

## 1.0.11

- **The pinned menu of the settings moves the page aside again**: pinning it moved the Claude Code tab's page
  instead (the first of the two on the page), so the settings stayed under the menu. Pointed at, the menu lies
  over the page as otp's does; pinned, the page is beside it - exactly as otp.
- The banner saying a new version is out is in the banner's own colour, not the browser's visited purple, which
  could not be read on its yellow; every link of the pages is in their blue, visited or not.

## 1.0.10

- **A scroll bar for Claude Code full-screen**: Claude Code's full-screen look keeps its history itself, so
  tmux had none and the bar beside the terminal hid itself. It is now a jog wheel there - dragged up goes back,
  down comes on, its ends a page - and a finger on the terminal moves it, as the mouse wheel does.
- **The rails do not move under the pointer**: the list of terminals slides out with the pin, *New terminal* and
  every chat's icon exactly where they were; what an item of a rail says is shown beside the rail, not over the items.
- **The right button in the Files tab**: on a file or a folder (open, a new Claude Code in it, copy the path,
  a new folder or file in it, download, rename, delete) and on the list (new folder or file, upload, a new
  Claude Code, copy the path, read again); a finger held still does the same on a tablet.

## 1.0.9

- **The history on a tablet**: a finger on the terminal moves back through tmux's history and on again, a bar
  on its right is always there to drag or tap, *Back to now* returns; **History** shows every line tmux keeps,
  with its colours, in a window that scrolls by finger - copied or downloaded.
- **A finger held still is the right button**: on the terminal, the chats, the files and the folders.
- **The folder of the chats** (Settings → Claude Code): a new chat starts in it or under it only - the daemon
  refuses the rest; the folder picker starts there, never goes above it, and makes, renames and deletes
  folders and files (buttons, right button, a finger held still). The chat's own files make new files too.
- **Starting as on claude.ai**: a greeting, a box to write the task in, the folder, model, permission mode and
  effort as chips, Enter starts Claude Code on it; the chats going on as cards below.
- **Every option of Claude Code** in the new chat dialog as fields - name, effort, fallback model, every
  permission mode, allowed / denied / built-in tools, more folders, the system prompt added or replaced, the
  agent, MCP configs, settings and their sources, plugin folders, worktree, fork, session ID, autocompact,
  Remote Control, verbose, debug, safe mode, bare, restricted, Chrome, IDE, brief, no slash commands, a screen
  reader, the first message, a session in the background - kept as how the account's chats start when asked.
- **The Claude Code tab**, for an account and a project: settings (fields and JSON), permissions (allow, ask,
  deny), hooks, memory (CLAUDE.md), MCP servers (added, removed, checked, let in), agents, commands, skills,
  output styles, plugins and marketplaces, background sessions (opened, logs, stopped, removed), usage by day,
  model and folder, keybindings, the sign-in and the doctor.
- The model, the permission mode, the more words and the last folder of a new chat are remembered again: they
  were dropped by the daemon.

## 1.0.8

- **Settings → Accounts as otp's**: every account in one row with its role chosen right there and the same
  buttons in the same places - its Linux account and folders, a new password typed by the administrator,
  stop or let it sign in, remove it, **put its columns back as they come**, reset its second step - a button
  that does not apply dimmed and saying why; how many tables each has laid out; *Signed in now* as otp's,
  each sign-in ended with a question first.
- **The menus hide themselves with their pin on every screen 981 px wide or more**, whatever the browser says
  about a touch screen or a mouse; narrower, they lie across the top as before.

## 1.0.7

- **The menu of the settings in otp's order**: Claude Code, Signing in (codes by e-mail and SMS, message
  texts), Mail (mail, outgoing mail), Access (accounts, certificates and TLS, firewall), Server (network,
  time, restart, system updates, SSH keys), Data (the database, backups, export and import), Updates.
- **The menu hides itself and has its pin** on a computer with a touch screen as well: it was only so where
  the browser said there was a mouse and nothing else (the list of terminals likewise).
- **The address of the database saved as otp saves it**: with Save, into `/etc/ai/config.json` - and only once
  that database opens and its tables are put right; it was refused before.

## 1.0.6

- **The database as otp's**: SQLite, **MariaDB or PostgreSQL**, on this machine or another. *Settings → The
  database* is otp's pane: fill the address in, **try it**, **set it up** (the database and an account with
  rights on it alone, its password made here; the server's administrator used once and kept nowhere),
  **carry everything across**, **start using it** - and back the same way. What is here is never touched by
  any of it. The address is the only setting kept in `/etc/ai/config.json` alone.
- **Dumps by the engine's own program** every night (SQLite's backup, `pg_dump`, `mariadb-dump`) and
  **portable copies** that go into any of the three; both downloaded with the key of their secrets locked with
  a passphrase (or without it), and put back from the list or from a file sent - read and shown first, a copy
  of what is replaced made before. The disk it is on and how fast it grows, every table, check it, give the
  disk back, forget old records, erase the collected data, and the database server tuned for its machine.
- **Otp's outgoing mail**: every mail is tried at once, and what the other side does not take yet
  (greylisting, a server away) is tried again by itself - a code while it is good; refused for good it is
  failed. Sent again or taken out by hand, searched by field, counted in a badge in the menu. A test mail
  goes straight (every step shown) or through it.
- **Otp's message texts designer**: the mail of a code is otp's HTML mail with its plain text part, edited as
  it arrives - bold, italic, colours, links, the parts filled in as blue chips - in Czech and English; the
  SMS beside a phone, counted in parts; previewed, sent as a sample, put back as it comes. The texts of 1.0.5
  are carried over.
- **Upgrades and Accounts as otp's**: this server, the web with the newer versions to choose from, a package
  dropped in and held until Upgrade, going back to a safe version with what changed, the upgrade with how far
  it is, what root said last; the accounts in otp's order.
- The installer: `--with-db mariadb|postgres` puts in the driver and the client tools beforehand (the engine in
  use gets them by itself on an upgrade), `--no-db-restart`.
- A second daemon that cannot have the port no longer writes its own token over the running one's.
- Going back is possible to 1.0.6 at the oldest: the tables changed.

## 1.0.5

- **The files of a chat** beside its terminal: its own folder and what is under it, never above it (the
  daemon refuses a path outside it); the right button hands a file to Claude (`@path`), opens, downloads,
  renames or deletes it; files dropped onto the list are uploaded there.
- **The right mouse button**, with a menu drawn as claude.ai draws one: on the terminal - copy, paste,
  select or copy the screen, a file for Claude, the chat's files, commands, clear the screen - and on a chat
  in the list (or its ⋯): open, open in a new window, pin, rename in its row, its files, a new Claude Code in
  its folder, the command to attach it, start it again, end it. tmux's own menu on that button is off.
- **Pinned chats** at the top of the list, kept with the account (wherever you sign in).
- **The list of terminals and the menu of settings hide themselves** at the edge of the screen as otp's do,
  slide out when pointed at, and stay out once pinned; not pinned is the default, as in otp.
- Signing out (or a sign-in ended by an administrator) closes that window's view of a terminal - never the
  terminal; **Sign out everywhere** under your name. Several sign-ins at once see the same terminals live.

## 1.0.4

What otp has and ai had not yet - taken over from otp 1.0.161, its code and its pages:

- **The second step of signing in**: an authenticator app (a QR code made here), a code by e-mail or by
  SMS; for everybody when switched on (`ai --admin-2fa on`), set up by each account at its first sign-in,
  reset from Accounts or with `ai --reset-2fa NAME`. Until it is given, a sign-in can do nothing else.
- **Secrets sealed** in the database with `/var/lib/ai/secrets.key`, as otp seals them.
- **Locked out**: the addresses and names counted after wrong passwords and codes, listed and cleared
  (Accounts; `ai --lockouts`, `ai --unlock`).
- **Mail**: SMTP or straight to the recipients' MX, a test with every step, the authorities of your own;
  notices of warnings and failures by mail.
- **SMS**: an HTTP gateway, a modem's spool or a Teltonika gateway, a test, its certificates.
- **Message texts** in Czech and English, edited on the pages; **Outgoing mail**: every mail and SMS sent.
- **Certificates and TLS** as otp's: PEM or PFX uploaded, a request (CSR) made here, self-signed; the chain
  sorted and checked; standard, intermediate, modern or custom TLS, DH parameters, HSTS
  (`ai --tls-import`, `--tls-preset`, `--tls-dh`, `--tls-hsts`).
- **The database**: a copy every night with its key, downloaded, put back (`ai --db-copy`, `--db-restore`).
- **Backups to other machines**: a folder, FTP, FTPS, SFTP, SCP, SMB; locked with a password, on a schedule,
  RESTORE.md beside each, put back from the pages or with `ai --restore-bundle`.
- **Export and import** of the whole configuration, with the secrets locked by a passphrase.
- **Going back to an older version** - only to a safe one (`ai --downgrade-check`, `ai --downgrade`).
- **About**: what the server runs on, Python to PHP's extensions.
- **The columns of every table** laid out per person (otp's cols.js); your own settings to a file and back.
- The PHP running the pages said when it may be without the php2shell fix.
- The settings rail grouped as otp's: Access, Messages, Server, Data, Updates.
- The console: the second step, the locked out, a reset, the copies, backups, export, a test mail, going back.
- install.sh puts in smbclient (samba-client) for backups to a share.

## 1.0.3 — 29 October 2026

**The command line and the console, as otp's**
- `ai --console`: otp's console, whole - the menus on a text screen, windows
  and forms, lists to scroll, the live log and the journal with grep as you
  type - with ai's menus: status and checks, terminals (opened right there in
  tmux, started, ended), accounts, settings, firewall and access, the server
  (network, time, updates, SSH keys, certificate, power), upgrades, the
  service. It opens by itself when root signs in (`ai --console-at-login
  on|off`); never inside a terminal of the pages.
- In colour, as otp's: colorama when it is there (install.sh installs
  python3-colorama), the same escape sequences by hand when it is not; every
  table and line coloured; `--help` in two columns; `--json` and `--no-color`.
- New commands: `--check`, `--open-web` (HTTP and HTTPS let in by firewalld,
  ufw or iptables), `--fw status|on|off`, `--fw-open PORT [--from CIDR]`,
  `--fw-del N`, `--pages-from`, `--change-keep`, `--change-back`, `--net`,
  `--ntp`, `--osup check|upgrade|status`, `--sshkeys`, `--sshkey-add`,
  `--cert`, `--reboot`, `--poweroff`, `--screen`, `--end`, `--restart-term`,
  `--again`, `--new … --shell|--continue|--pick|--model`, `--del-user`,
  `--disable-user`, `--enable-user`, `--set-role`, `--set-run-as`,
  `--end-sign-ins`, `--sign-ins`, `--log`, `--set KEY=VALUE`,
  `--upgrade-status`.

## 1.0.2 — 29 October 2026

**install.sh gone through against otp's, line by line**
- The first account: a password given is neither printed at the end nor said
  to be changed; one made by the installer is printed and has to be changed at
  the first sign-in (it did not have to).
- Who may reach the pages is checked before anything is installed, and the
  address you are signed in from over SSH, if it is not among them, is offered
  to be added - not shut out of the pages you just installed.
- php-fpm is reloaded, not restarted - the other PHP sites of the machine go
  on - and started when it was not running.
- Python 3.9 or newer is checked; a command that fails says on which line.
- Debian and Ubuntu get the SSH client only, not an SSH server.
- `--rewrite-nginx` keeps the file there before in /etc/nginx/ai-backups/
  (the last ten).
- At the end, the pages' address by IP too, for until the name is in DNS.
- Without `SSH_CLIENT` (installed from the console) it stopped at once.

## 1.0.1 — 29 October 2026

**install.sh asks, as otp's does**
- A fresh install asks *A few questions* before it does anything, Enter keeping
  what is in brackets: the pages' hostname (FQDN), who may reach the pages, the
  first account and its password (typed twice, unseen; empty = one made and
  printed), the Linux account the terminals run as (made when it is not there),
  and whether to install Claude Code for root. The hostname was taken from the
  machine without asking. `--yes` takes what is in brackets, as before.
- A setting changed on the command line (`ai --setting`) is taken by the
  running daemon within a minute.

## 1.0.0 — 29 October 2026

**The first version: Claude Code on the server, from the browser**
- Terminals of Claude Code and shells in tmux, one tmux server per Linux
  account in a systemd scope of its own: closing the browser, losing the
  connection or restarting ai ends none of them. xterm.js on a WebSocket,
  reconnected by itself; several windows on one terminal; the last screen of
  one that ended kept; started again, ended, renamed, opened in a window of
  its own; `ai --attach` on the server.
- The whole keyboard: Ctrl and Alt combinations, arrows, F1-F12, Shift+Enter
  for a new line, copy and paste, and *All keys* (Keyboard Lock) for the keys
  a browser keeps; Ctrl, Alt and the special keys on screen for a phone;
  Claude Code's commands from a list; a box for long text.
- Files: a browser of the server's files with upload (button, drag and drop,
  Ctrl+V), download (folders as .zip), text files edited, pictures shown; files
  and pictures dropped or pasted into a terminal handed to Claude.
- Conversations: every one Claude Code kept, by folder, resumed in a new
  terminal.
- Claude Code installed, updated and checked for each Linux account from the
  pages; the model, the permission mode and more words per terminal.
- Accounts: administrators and users, each with the Linux account its
  terminals run as and the folders of its files; Linux accounts made here.
- The server, as otp 1.0.161 draws it: firewall and who may reach the pages,
  network, time, system updates, root's SSH keys, restart and power off;
  certificate and TLS; changes that could cut you off taken back unless kept.
- New versions signed (Ed25519), from GitHub or sent from the pages, put in by
  hand or by themselves; the last ten in release/.
- Czech and English.
